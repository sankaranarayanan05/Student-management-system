import java.sql.*;
import java.util.ArrayList;

public class DatabaseHelper {
    
    private static final String URL = "jdbc:mysql://localhost:3306/studentdb";
    private static final String USER = "root";
    private static final String PASSWORD = "your_password_here";  // CHANGE THIS TO YOUR MYSQL PASSWORD
    
    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
    
    public static boolean addStudent(String name, int age, double marks) {
        String query = "INSERT INTO students (name, age, marks) VALUES (?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setDouble(3, marks);
            pstmt.executeUpdate();
            return true;
            
        } catch (SQLException e) {
            System.out.println("Error adding student: " + e.getMessage());
            return false;
        }
    }
    
    public static ArrayList<Student> getAllStudents() {
        ArrayList<Student> students = new ArrayList<>();
        String query = "SELECT * FROM students ORDER BY id";
        
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                students.add(new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getInt("age"),
                    rs.getDouble("marks")
                ));
            }
            
        } catch (SQLException e) {
            System.out.println("Error fetching students: " + e.getMessage());
        }
        
        return students;
    }
    
    public static Student getStudentById(int id) {
        String query = "SELECT * FROM students WHERE id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getInt("age"),
                    rs.getDouble("marks")
                );
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding student: " + e.getMessage());
        }
        
        return null;
    }
    
    public static ArrayList<Student> searchByName(String name) {
        ArrayList<Student> results = new ArrayList<>();
        String query = "SELECT * FROM students WHERE name LIKE ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, "%" + name + "%");
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                results.add(new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getInt("age"),
                    rs.getDouble("marks")
                ));
            }
            
        } catch (SQLException e) {
            System.out.println("Error searching: " + e.getMessage());
        }
        
        return results;
    }
    
    public static boolean updateStudent(int id, String name, int age, double marks) {
        String query = "UPDATE students SET name = ?, age = ?, marks = ? WHERE id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setDouble(3, marks);
            pstmt.setInt(4, id);
            
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error updating student: " + e.getMessage());
            return false;
        }
    }
    
    public static boolean deleteStudent(int id) {
        String query = "DELETE FROM students WHERE id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error deleting student: " + e.getMessage());
            return false;
        }
    }
    
    public static ArrayList<Student> getStudentsSortedByMarks() {
        ArrayList<Student> students = new ArrayList<>();
        String query = "SELECT * FROM students ORDER BY marks DESC";
        
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                students.add(new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getInt("age"),
                    rs.getDouble("marks")
                ));
            }
            
        } catch (SQLException e) {
            System.out.println("Error sorting students: " + e.getMessage());
        }
        
        return students;
    }
}
