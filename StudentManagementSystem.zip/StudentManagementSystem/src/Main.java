import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    
    static Scanner sc = new Scanner(System.in);
    
    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════════════╗");
        System.out.println("║   STUDENT MANAGEMENT SYSTEM            ║");
        System.out.println("╚════════════════════════════════════════╝");
        
        int choice;
        do {
            printMenu();
            choice = sc.nextInt();
            
            switch (choice) {
                case 1: addStudent(); break;
                case 2: viewAll(); break;
                case 3: searchStudent(); break;
                case 4: updateStudent(); break;
                case 5: deleteStudent(); break;
                case 6: sortByMarks(); break;
                case 7: System.out.println("\n✅ Thank you for using SMS. Goodbye!"); break;
                default: System.out.println("❌ Invalid option! Please try again.");
            }
        } while (choice != 7);
        
        sc.close();
    }
    
    static void printMenu() {
        System.out.println("\n─────────────────────────────────────────");
        System.out.println("              MAIN MENU");
        System.out.println("─────────────────────────────────────────");
        System.out.println("1. Add Student");
        System.out.println("2. View All Students");
        System.out.println("3. Search Student");
        System.out.println("4. Update Student");
        System.out.println("5. Delete Student");
        System.out.println("6. Sort Students by Marks");
        System.out.println("7. Exit");
        System.out.println("─────────────────────────────────────────");
        System.out.print("Enter your choice: ");
    }
    
    static void addStudent() {
        System.out.println("\n➕ ADD NEW STUDENT");
        sc.nextLine();
        
        System.out.print("Enter name: ");
        String name = sc.nextLine();
        
        System.out.print("Enter age: ");
        int age = sc.nextInt();
        
        System.out.print("Enter marks: ");
        double marks = sc.nextDouble();
        
        if (DatabaseHelper.addStudent(name, age, marks)) {
            System.out.println("✅ Student added successfully!");
        } else {
            System.out.println("❌ Failed to add student.");
        }
    }
    
    static void viewAll() {
        System.out.println("\n📋 ALL STUDENTS");
        ArrayList<Student> students = DatabaseHelper.getAllStudents();
        
        if (students.isEmpty()) {
            System.out.println("No students found in database.");
            return;
        }
        
        System.out.println("─────────────────────────────────────────────────────────────");
        for (Student s : students) {
            System.out.println(s);
        }
        System.out.println("─────────────────────────────────────────────────────────────");
        System.out.println("Total students: " + students.size());
    }
    
    static void searchStudent() {
        System.out.println("\n🔍 SEARCH STUDENT");
        System.out.println("1. Search by Name");
        System.out.println("2. Search by ID");
        System.out.print("Enter choice: ");
        int searchChoice = sc.nextInt();
        sc.nextLine();
        
        if (searchChoice == 1) {
            System.out.print("Enter name to search: ");
            String query = sc.nextLine();
            ArrayList<Student> results = DatabaseHelper.searchByName(query);
            
            if (results.isEmpty()) {
                System.out.println("❌ No students found with that name.");
            } else {
                System.out.println("\n✅ Search Results:");
                System.out.println("─────────────────────────────────────────────────────────────");
                for (Student s : results) {
                    System.out.println(s);
                }
                System.out.println("─────────────────────────────────────────────────────────────");
            }
            
        } else if (searchChoice == 2) {
            System.out.print("Enter student ID: ");
            int id = sc.nextInt();
            Student student = DatabaseHelper.getStudentById(id);
            
            if (student != null) {
                System.out.println("\n✅ Student Found:");
                System.out.println("─────────────────────────────────────────────────────────────");
                System.out.println(student);
                System.out.println("─────────────────────────────────────────────────────────────");
            } else {
                System.out.println("❌ No student found with ID " + id);
            }
        }
    }
    
    static void updateStudent() {
        System.out.println("\n✏️  UPDATE STUDENT");
        System.out.print("Enter student ID to update: ");
        int id = sc.nextInt();
        
        Student student = DatabaseHelper.getStudentById(id);
        
        if (student == null) {
            System.out.println("❌ Student with ID " + id + " not found!");
            return;
        }
        
        System.out.println("\nCurrent details: " + student);
        
        sc.nextLine();
        System.out.print("Enter new name (or press Enter to keep current): ");
        String name = sc.nextLine();
        if (name.isEmpty()) name = student.getName();
        
        System.out.print("Enter new age (or 0 to keep current): ");
        int age = sc.nextInt();
        if (age == 0) age = student.getAge();
        
        System.out.print("Enter new marks (or -1 to keep current): ");
        double marks = sc.nextDouble();
        if (marks == -1) marks = student.getMarks();
        
        if (DatabaseHelper.updateStudent(id, name, age, marks)) {
            System.out.println("✅ Student updated successfully!");
        } else {
            System.out.println("❌ Failed to update student.");
        }
    }
    
    static void deleteStudent() {
        System.out.println("\n🗑️  DELETE STUDENT");
        System.out.print("Enter student ID to delete: ");
        int id = sc.nextInt();
        
        Student student = DatabaseHelper.getStudentById(id);
        if (student == null) {
            System.out.println("❌ Student with ID " + id + " not found!");
            return;
        }
        
        System.out.println("\nStudent to delete: " + student);
        System.out.print("Are you sure? (yes/no): ");
        String confirm = sc.next();
        
        if (confirm.equalsIgnoreCase("yes")) {
            if (DatabaseHelper.deleteStudent(id)) {
                System.out.println("✅ Student deleted successfully!");
            } else {
                System.out.println("❌ Failed to delete student.");
            }
        } else {
            System.out.println("❌ Deletion cancelled.");
        }
    }
    
    static void sortByMarks() {
        System.out.println("\n📊 STUDENTS SORTED BY MARKS (Highest to Lowest)");
        ArrayList<Student> students = DatabaseHelper.getStudentsSortedByMarks();
        
        if (students.isEmpty()) {
            System.out.println("No students found in database.");
            return;
        }
        
        System.out.println("─────────────────────────────────────────────────────────────");
        int rank = 1;
        for (Student s : students) {
            System.out.println("Rank " + rank++ + " → " + s);
        }
        System.out.println("─────────────────────────────────────────────────────────────");
    }
}
