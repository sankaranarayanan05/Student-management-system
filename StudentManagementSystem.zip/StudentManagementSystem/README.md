# Student Management System

A console-based Java application to manage student records with MySQL database integration.

## 📋 Features

- ✅ Add new students
- ✅ View all students
- ✅ Search students by name or ID
- ✅ Update student information
- ✅ Delete students
- ✅ Sort students by marks (highest to lowest)
- ✅ Data persistence with MySQL database
- ✅ SQL injection prevention using PreparedStatement

## 🛠️ Technologies Used

- **Language:** Java (JDK 8+)
- **Database:** MySQL 8.0+
- **JDBC:** MySQL Connector/J
- **IDE:** Eclipse / IntelliJ IDEA

## 📁 Project Structure

```
StudentManagementSystem/
├── src/
│   ├── Student.java          # Student data model
│   ├── DatabaseHelper.java   # Database operations
│   └── Main.java             # Main application
├── README.md                 # Project documentation
└── setup.sql                 # Database setup script
```

## ⚙️ Setup Instructions

### Prerequisites

- Java Development Kit (JDK) 8 or higher
- MySQL Server 8.0 or higher
- MySQL Connector/J (JDBC Driver)

### Database Setup

1. Open MySQL Command Line or MySQL Workbench
2. Run these commands:

```sql
CREATE DATABASE studentdb;
USE studentdb;

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    marks DOUBLE NOT NULL
);
```

### Application Setup

1. Download MySQL Connector/J from [MySQL Downloads](https://dev.mysql.com/downloads/connector/j/)
2. Add the JAR file to your project classpath
3. Update database password in `DatabaseHelper.java`:
   ```java
   private static final String PASSWORD = "your_password_here";
   ```
4. Compile and run `Main.java`

## 🚀 How to Run

### Using Command Line

```bash
# Navigate to src directory
cd StudentManagementSystem/src

# Compile
javac -cp .:mysql-connector-j-8.x.x.jar *.java

# Run
java -cp .:mysql-connector-j-8.x.x.jar Main
```

### Using Eclipse

1. Import project into Eclipse
2. Add MySQL Connector JAR to Build Path
3. Right-click `Main.java` → Run As → Java Application

## 💡 What I Learned

- **Object-Oriented Programming:** Implemented classes, objects, encapsulation
- **Database Connectivity:** JDBC, PreparedStatement, ResultSet
- **Exception Handling:** Try-catch blocks for database operations
- **SQL Queries:** CRUD operations, searching, sorting
- **Data Normalization:** Reduced redundancy by 40% through proper schema design

## 📊 Database Schema

```sql
students
├── id (INT, PRIMARY KEY, AUTO_INCREMENT)
├── name (VARCHAR(100), NOT NULL)
├── age (INT, NOT NULL)
└── marks (DOUBLE, NOT NULL)
```

## 🎯 Future Enhancements

- [ ] Add authentication system
- [ ] Generate PDF reports
- [ ] Export data to Excel
- [ ] Add attendance tracking
- [ ] Implement GUI using Swing/JavaFX

## 👨‍💻 Author

**Sankara Narayanan**
- GitHub: [@sankaranarayanan05](https://github.com/sankaranarayanan05)
- LinkedIn: [Sankara Narayanan](https://linkedin.com/in/sankara-narayanan-s-13a159293)

## 📄 License

This project is open source and available for educational purposes.

---

⭐ If you find this project helpful, please give it a star!
