-- Student Management System Database Setup
-- Run this script in MySQL to set up the database

-- Create database
CREATE DATABASE IF NOT EXISTS studentdb;

-- Use the database
USE studentdb;

-- Create students table
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL CHECK (age > 0 AND age < 150),
    marks DOUBLE NOT NULL CHECK (marks >= 0 AND marks <= 100)
);

-- Insert sample data (optional)
INSERT INTO students (name, age, marks) VALUES 
('Rahul Kumar', 20, 85.5),
('Priya Sharma', 21, 92.0),
('Amit Patel', 19, 78.5),
('Sneha Reddy', 22, 88.0),
('Vijay Singh', 20, 95.5);

-- Verify the setup
SELECT * FROM students;

-- Show table structure
DESCRIBE students;
